#ifndef __COMMON_H__
#define __COMMON_H__

#include <opencv2/opencv.hpp>
#include <vector>

static cv::Rect increase( cv::Rect r, int e=1 )
{
	return r + cv::Size(2*e,2*e) + cv::Point(-e,-e);
}
static cv::Mat decrease( const cv::Mat& m, int e=1 )
{
	cv::Rect r( cv::Point(0,0), m.size() );
	r = r + cv::Size(-2*e,-2*e) + cv::Point(e,e);
	return m(r);
}

#endif