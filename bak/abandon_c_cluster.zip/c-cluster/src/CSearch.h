#ifndef __CSEARCH_H__
#define __CSEARCH_H__

#include "common.h"

class CSearch
{
	typedef std::vector< cv::Point > VecPoints;

public:
    cv::Rect imsize;

public:
    explicit CSearch( cv::Size imsz );
	cv::Rect get_roi( cv::Rect obj, int rad );
	int get_pos( cv::Rect obj,         int rl, cv::Rect& roi, VecPoints& pos );
	int get_pos( cv::Rect obj, int rs, int rl, cv::Rect& roi, VecPoints& pos, int num );
};

#endif