// http://www.cppblog.com/jb8164/archive/2008/02/26/43260.html

// ��д����֮ǰ, ��Ҫ֪��һЩ����֪ʶ, ���ο��Ⱦ�ָ����
// cv::Mat  �ṹ��, �� (0,0,32,24) Ϊ��, �������Ϊ 0, ����Ϊ 32, �ҵ�Ϊ 31
// cv::Rect �ṹ��, �� (0,0,32,24) Ϊ��, �������Ϊ 0, ����Ϊ 32, �ҵ�Ϊ 32
#define _CRT_SECURE_NO_WARNINGS

#include <string>
using std::string;
#include <iostream>
using std::cout;
using std::endl;
#include <iomanip>
using std::setw;
using std::setfill;
#include <fstream>
using std::ofstream;
#include <opencv2/opencv.hpp>
using cv::Mat;
using cv::Rect;
using cv::Size;
using cv::Point;
using cv::Scalar;

#include "Mat/mat.h"
#include "CSearch.h"

typedef cv::Vec<unsigned char, 1> Vec1b;
typedef std::vector< cv::Point > VecPoints;

/*
	modified mat_sparse.cpp | Sparse::Sparse() | rand.rect()->rand.rect(36,36)
*/
void copyinfo( void )
{
	printf("This code is provided AS IS without warranty of any kind. \n");
	printf("Author further disclaims all implied warranties including, \n");
	printf("without limitation, any implied warranties of merchantability \n");
	printf("or of fitness for a particular purpose. \n");
	printf("The entire risk arising out of the use \n");
	printf("or performance of this code and documentation remains with you. \n");
	printf("In no event shall its authors, or anyone else involved \n");
	printf("in the creation, production, or delivery of the code be liable \n");
	printf("for any damages whatsoever (including, without limitation, \n");
	printf("damages for loss of business profits, business interruption, \n");
	printf("loss of business information, or other pecuniary loss) \n");
	printf("arising out of the use of or inability to use the code or documentation, \n");
	printf("even if author has been advised of the possibility of such damages. \n\n");
	printf("All Rights Reserved \n");
	printf("CopyRight, 2013-2014, Dolby Du & Yunxia Wu, CUMTB. \n\n");
	printf("��Ȩ: ����������Ȩ����, �Ա����κεĲ��ֻ�ȫ��֮���þ���������. \n");
	printf("����: ���Ĳ�Ϊ�����ķ��պ�/���������ṩ�κε���, ��������������ʾ��ʾ. \n\n");
}
class cmdline
{
public:
	int nstart, nend;
	char *icurpath, *ocurpath, *fileext;

	cmdline() : nstart(1), nend(1),
		icurpath("C:\\Users\\du\\Pictures\\B"),
		ocurpath(".\\results\\"), fileext("bmp")
	{
	}

	void decode( char** argv )
	{
		icurpath   = argv[1];
		ocurpath   = argv[2];
		fileext    = argv[3];
		nstart = atoi( argv[4] );
		nend   = atoi( argv[5] );
	}

	cv::Size size()
	{
		return cv::imread( read(nstart).c_str() ).size();
	}

	typedef int iterator;
	int begin( void )
	{
		return nstart;
	}
	int end( void )
	{
		return nend;
	}
	string read( int i )
	{
		char tmp[200];
		sprintf( tmp, "%s%04d.%s", icurpath, i, fileext );
		return string(tmp);
	}
	string write( int i )
	{
		char tmp[200];
		sprintf( tmp, "%s%04d.%s", ocurpath, i, "csv" );
		return string(tmp);
	}
};
int main( int argc, char* argv[] )
{
	copyinfo();

	// decode 
	cmdline cmd;
	if( argc > 1 ) { cmd.decode( argv ); }

	// initialize with default location
	CSearch filter( cmd.size() );
	Rect obj = filter.imsize;
	mat::Sparse<DIMSZ> base( obj.size() );

	// each picture is a sample, so obj equals to roi
	Rect roi;  VecPoints pos;
	int nsamp = filter.get_pos( obj, 3, roi, pos );
	if( 1 != nsamp ) { perror("multipul targets found in one picture\n"); return 1; }
	
	for( cmdline::iterator it=cmd.begin(); it<=cmd.end(); ++it )
	{
		Mat orig = cv::imread( cmd.read(it).c_str() );  // if(!orig.data){ exit(1); }
		Mat gray;    cvtColor( orig, gray, CV_RGB2GRAY );
		mat::Proj<Vec1b> hInt;
		hInt.store( gray(roi), roi.tl() );
		// hInt.integral();
		cout << "saved, but not to be integraled, and never" << endl;
	
		// \begin{ show }
		Mat vis = orig.clone();
		for( int r=0; r<nsamp; r++ )
		{
			for( int c=0; c<DIMSZ; c++ )
			{
				for( size_t n=0; n<base.val[c].size(); n++ )
				{
					rectangle( vis, base.box[c][n], base.color[c][n], 2 );
				}
			}
			Rect ins = roi + Size(-base.box[0][0].width, -base.box[0][0].height);
			cout << ins << roi << endl << endl;
			rectangle( vis, ins, Scalar(0,0,200), 2 );
			rectangle( vis, roi, Scalar(200,0,0), 2 );
		}
		// \end{ show }

		// allocated a data set
		Mat1296x50b sampmat;
		ofstream dev( cmd.write(it).c_str() );
		base.raw_features( hInt, pos[0], sampmat );  // I said, only one position!
		dev << cv::format( Mat(sampmat), "csv" );
		dev.close();
		imshow( "CT", vis );  // Display
		cv::waitKey(0);
		cv::destroyWindow( "CT" );
	}
	return 0;
}