#include "CSearch.h"
using cv::Rect;
using cv::Size;
using cv::Point;


CSearch::CSearch( Size imsz )
{
	imsize = Rect( 1, 1, imsz.width-2, imsz.height-2 );
}

int CSearch::get_pos( Rect obj, int rl, Rect& roi, VecPoints& pos )
{
	Rect tls = Rect( obj.x-rl, obj.y-rl, 2*rl, 2*rl );
	roi = imsize & ( tls + obj.size() );
	tls = roi + Size(-obj.width,-obj.height) + Size(1,1);  // for inside()

	// r^2<=9  =/=  r^2<16
	int rl2=(rl+1)*(rl+1);

	int nsamp=0;  pos.clear();
	for( int x=-rl; x<=rl; x++ )
	{
		for( int y=-rl; y<=rl; y++ )
		{
			Point pt = obj.tl() + Point( x, y );
			if( pt.inside( tls ) )
			{
				int d2 = x * x + y * y;
				if( d2 < rl2 )
				{
					pos.push_back( pt );
					nsamp++;
				}
			}
		}
	}
	pos.resize( nsamp );
	//
	return nsamp;
}


static inline float uprob( void )
{
	static cv::RNG cvseed;
	return (float)cvseed.uniform(0.,1.);
}
int CSearch::get_pos( Rect obj, int rs, int rl, Rect& roi, VecPoints& pos, int num )
{
	Rect tls = Rect( obj.x-rl, obj.y-rl, 2*rl, 2*rl );
	roi = imsize & ( tls + obj.size() );
	tls = roi + Size(-obj.width,-obj.height) + Size(1,1);  // for inside()

	// r^2<=9  =/=  r^2<16
	int rs2=rs*rs, rl2=(rl+1)*(rl+1);
	float prob = (float)num / (float)tls.area();

	int nsamp=0;  pos.clear();
	for( int x=-rl; x<=rl; x++ )
	{
		for( int y=-rl; y<=rl; y++ )
		{
			Point pt = obj.tl() + Point( x, y );
			if( pt.inside( tls ) )
			{
				int d2 = x * x + y * y;
				if( rs2 <= d2 && d2 < rl2 && uprob() < prob )
				{
					pos.push_back( pt );
					nsamp++;
				}
			}
		}
	}
	pos.resize( nsamp );
	//
	return nsamp;
}