#ifndef __MAT_PROJ_CPP__
#define __MAT_PROJ_CPP__


#include "mat.h"
//
using cv::Mat;
using cv::Point;

template< typename TP_ >
void mat::Proj<TP_>::store( const Mat& m, Point p )
{
	this->row0 = p.y;
	this->col0 = p.x;
	this->nrow = m.rows;
	this->ncol = m.cols;
	this->smat = m.clone();
}
template< typename TP_ >
void mat::Proj<TP_>::integral( void )
{
	Mat dst( smat.rows+1, smat.cols+1, CV_8UC(TP_::channels) );
	//
	TP_ vec; vec.zeros();
	for( int c=0; c<dst.cols; c++ )
	{
		for( int r=0; r<dst.rows; r++ )
		{
			if( 0==r || 0==c )
			{
				vec += TP_::zeros();
			}
			else
			{
				vec += smat.at<TP_>(r-1,c-1);
			}
			dst.at<TP_>(r,c) = vec;  // ��row, ��
		}
	}
	//
	vec.zeros();
	for( int r=0; r<dst.rows; r++ )
	{
		for( int c=0; c<dst.cols; c++ )
		{
			vec += dst.at<TP_>(r,c);
			dst.at<TP_>(r,c) = vec;  // ��col, ��
		}
	}
	//
	smat = dst;
	this->nrow++;
	this->ncol++;
}
template< typename TP_ >
TP_ mat::Proj<TP_>::at( int r, int c )
{
	return this->smat.at< TP_ >(r-row0, c-col0);
}

// declare a prob actual template class
// this may increase the volumn of obj files
// template class mat::Proj< unsigned char >;

#endif