#ifndef __MAT_BASE_CPP__
#define __MAT_BASE_CPP__

#include "mat.h"
using cv::Vec;
using cv::Mat;
// define R-like function

template<typename TP_> inline TP_ mat::colMean( cv::Mat col )
{
	TP_ sum;
	int N = col.rows;
	for( int r=0; r<N; r++ )
	{
		sum += col.at<TP_>(r,0);
	}
	return sum / N;
}

template<typename TP_> inline TP_ mat::colMom2( cv::Mat col )
{
	TP_ sum;
	int N = col.rows;
	for( int r=0; r<N; r++ )
	{
		sum += col.at<TP_>(r,0).mul( col.at<TP_>(r,0) );
	}
	return sum / N;
}

#endif