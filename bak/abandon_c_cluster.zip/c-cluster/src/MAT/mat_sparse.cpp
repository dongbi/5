#ifndef __MAT_SPARSE_CPP__
#define __MAT_SPARSE_CPP__

#include "mat.h"
//
using cv::Vec;
using cv::Mat;
using cv::Rect;
using cv::Size;
using cv::Point;
using cv::Scalar;
using std::vector;

class CRand
{
	const static int seed = 19880815;

    int wid, hgh;
    
public:
	int n11( void ){ return (rand()%2) ? -1 : 1; }
	int n23( void ){ return (rand()%2) ?  2 : 3; }

    CRand( int w, int h )
	{
		this->wid = w;
		this->hgh = h;
		srand( seed );
	}
    Rect rect( void )
	{
		// 0col=0, ~col=31, wid=32
		// 0wid=0, ~wid=32, wid=32
        int l, r;
        while( true )
        {
            l = rand() % (wid+1);
            r = rand() % (wid+1);
            if( l < r ){ break; }
        }

        int t, b;
        while( true )
        {
            t = rand() % (hgh+1);
            b = rand() % (hgh+1);
            if( t < b ){ break; }
        }
        
        return Rect( l, t, r-l, b-t );
	}
	// random rect of equal size
	Rect rect( int w, int h )
	{
		// argv: 10, 3
		// 0 1 2 3 4 5 6 [7 8 9]
		// 0~7 is OK, so we % 8
        int l = rand() % (wid-w+1);
        int t = rand() % (hgh-h+1);
        return Rect( l, t, w, h );
	}
};


template< int NUM_ >
mat::Sparse<NUM_>::Sparse( Size sz )
{
	CRand rnd( sz.width, sz.height );
	srand( (unsigned int)19900218L );

	for( int i=0; i<NUM_; i++ )
	{
		int n23 = rnd.n23();
		for( int j=0; j<n23; j++ )
		{
			this->val[i].push_back( rnd.n11() );
			this->box[i].push_back( rnd.rect(RNDSZ,RNDSZ) );
			this->color[i].push_back( Scalar(rand()%256,rand()%256,rand()%256) );
		}
		this->val[i].resize( n23 );
		this->box[i].resize( n23 );
	}
}

/*
  // will not work
  A.row(i) = A.row(j);

  // works, but looks a bit obscure.
  A.row(i) = A.row(j) + 0;

  // this is a bit longer, but the recommended method.
  A.row(j).copyTo(A.row(i));

  // if you use vector
  vec.clear();
  vec.pushback();
  vec.resize(_NUM);
  Mat(vec).reshape(9,50);
*/
template< int NUM_ >
template< typename TP_ >
void mat::Sparse<NUM_>::get_features( Proj<TP_> iint, Point base, Mat& row )
{
	for( int c=0; c<NUM_; c++ )
	{
		TP_ acc;
		for( size_t n23=0; n23<val[c].size(); n23++ )
		{
			int  val = this->val[c][n23];
			Rect roi = this->box[c][n23] + base;
			// want ( 0, 0) -> ( 0, 0)
			// iint (-1,-1) -> ( 0, 0)
			// real ( 0, 0) -> ( 1, 1)
			int x0 = roi.x;
			int y0 = roi.y;
			int x1 = roi.x + roi.width;
			int y1 = roi.y + roi.height;
			//
			acc += val * ( iint.at(y0,x0) + iint.at(y1,x1) - iint.at(y1,x0) - iint.at(y0,x1) );
		}
		row.at< TP_ >(0,c) = acc;
	}
}

template< int NUM_ >
template< typename TP_ >
void mat::Sparse<NUM_>::raw_features( Proj<TP_> orig, Point base, Mat1296x50b& m  )
{
	m.zeros();
	for( int c=0; c<NUM_; c++ )
	{
		for( size_t n23=0; n23<val[c].size(); n23++ )
		{
			int  val = this->val[c][n23];
			Rect roi = this->box[c][n23] + base;
			if( roi.area() != m.rows ) { perror("error size"); exit(1); }
			for( int dx=0; dx<roi.width; dx++ )
			{
				for( int dy=0; dy<roi.height; dy++ )
				{
					m(dx*roi.height+dy,c) += val * orig.at(roi.y+dy,roi.x+dx)[0];
				}
			}
		}
	}
}

// declare a prob actual template class
// this may increase the volumn of obj files
// template class mat::Sparse<50>;

#endif