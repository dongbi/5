#ifndef __MAT_H__
#define __MAT_H__

#include <vector>
#include <opencv2/opencv.hpp>

#define RNDSZ 6
#define DIMSZ 50
typedef cv::Matx< unsigned char, RNDSZ*RNDSZ, DIMSZ > Mat1296x50b;

namespace mat
{
	template<typename TP_> inline TP_ colMean( cv::Mat col );
	template<typename TP_> inline TP_ colMom2( cv::Mat col );
	//
	//
	template< typename TP_ > class Proj
	{
	public:
		cv::Mat smat;
		int nrow, ncol, row0, col0;
		void store( const cv::Mat&, cv::Point );
		void integral( void );
		TP_ at( int r, int c );
	};
	//
	//
	template< int NUM_ > class Sparse
	{
	public:
		std::vector<int>      val[ NUM_ ];
		std::vector<cv::Rect> box[ NUM_ ];
		std::vector<cv::Scalar> color[ NUM_ ];

		explicit Sparse( cv::Size sz );
		template<typename TP_> void get_features( Proj<TP_> iint, cv::Point base, cv::Mat& row );
		template<typename TP_> void raw_features( Proj<TP_> orig, cv::Point base, Mat1296x50b& m );
	};
}

#include "mat_base.cpp"
#include "mat_proj.cpp"
#include "mat_sparse.cpp"

#endif